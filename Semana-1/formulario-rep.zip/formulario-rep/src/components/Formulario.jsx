import { useState } from 'react';
import Card from './Card';

const Formulario = () => {
  //creamos los useState (estado)
  const [nombre, setNombre] = useState('');
  const [deporte, setDeporte] = useState('');
  const [error, setError] = useState('');
  const [card, setCard] = useState(false);

  //captura el ingreso de codigo del input
  const onChangeNombre = (e) => setNombre(e.target.value);
  const onChangeDeporte = (e) => setDeporte(e.target.value);

  //validando datos de input
  const validarInputNombre = () => {
    return nombre.trim().length >= 3;
  };
  const validarInputDeporte = () => {
    return deporte.trim().length >= 4;
  };

  const handleOnChange = (e) => {
    //reinicio por defecto
    e.preventDefault();

    //guardando los datos ingresados
    const validadorNombre = validarInputNombre();
    const validadorDeporte = validarInputDeporte();

    //condiciones para los estados de error y show card
    if (validadorNombre && validadorDeporte) {
      setCard(true);
      setError('Formulario completado');
    } else {
      setCard(false);
      setError('Formulario incompleto');
      console.log(`${deporte}, es el deporte favorito de ${nombre}`);
    }
  };

  return (
    <div>
      <h1>Deportes</h1>
      <h3>Nombre y deporte favorito</h3>
      <form onSubmit={handleOnChange}>
        <label htmlFor="nombre">Nombre: </label>
        <input
          type="text"
          placeholder="Ingresa tu nombre"
          value={nombre}
          onChange={onChangeNombre}
        />

        <label htmlFor="nombre"> Deporte: </label>
        <input
          type="text"
          placeholder="Ingresa un deporte"
          value={deporte}
          onChange={onChangeDeporte}
        />

        <button type="submit">Enviar</button>
        {!card ? null : <Card nombre={nombre} deporte={deporte} />}
        {error ? <p>{error}</p> : null}
      </form>
    </div>
  );
};

export default Formulario;
