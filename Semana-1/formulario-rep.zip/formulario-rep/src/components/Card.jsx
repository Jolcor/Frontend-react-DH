const Card = ({ nombre, deporte }) => {
  return (
    <div>
      <h2>Hola {nombre},</h2>
      <p>{deporte} es tu deporte favorito.</p>
    </div>
  );
};

export default Card;
